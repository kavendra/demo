<?php
  Why we use jquery instead of javascript?
  #Jquery is compatible with all browser but javascript is not.
  #Javascript code is complex and difficult.
  Jquery selector?  
?>